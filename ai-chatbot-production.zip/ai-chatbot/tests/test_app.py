from fastapi.testclient import TestClient
from app import app
from core import normalize_database_url,assert_isolated_resource
from uuid import uuid4
def test_health_and_headers():
 r=TestClient(app).get('/health');assert r.json()['status']=='ok';assert r.headers['x-frame-options']=='DENY'
def test_render_postgres_driver():assert normalize_database_url('postgresql://u:p@host/db').startswith('postgresql+psycopg://')
def test_evergreen_resource_guard():
 import pytest
 with pytest.raises(RuntimeError):assert_isolated_resource('postgresql://host/evergreen-staging-db','database URL')
def test_tenant_isolation():
 c=TestClient(app);email1=f"a{uuid4().hex}@example.com";email2=f"b{uuid4().hex}@example.com"
 t1=c.post('/api/register',json={'email':email1,'password':'StrongPass123!'}).json()['token'];t2=c.post('/api/register',json={'email':email2,'password':'StrongPass123!'}).json()['token']
 kid=c.post('/api/knowledge',json={'title':'Private policy','content':'A confidential tenant-only policy.'},headers={'Authorization':f'Bearer {t1}'}).json()['id']
 assert c.get('/api/knowledge',headers={'Authorization':f'Bearer {t2}'}).json()==[]
 assert c.delete(f'/api/knowledge/{kid}',headers={'Authorization':f'Bearer {t2}'}).status_code==404
