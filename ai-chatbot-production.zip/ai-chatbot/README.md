# SupportPilot AI

Deployable multi-tenant customer-support chatbot with account isolation, conversation history, business knowledge management, grounded responses, source labels, rate limiting, and an OpenAI-compatible model provider.

## Run

1. Copy `.env.example` to `.env` and set `CHATBOT_APP_SECRET` and `CHATBOT_OPENAI_API_KEY`.
2. Run `docker build -t supportpilot .`
3. Run `docker run --env-file .env -p 8101:8101 supportpilot`
4. Open `http://localhost:8101`. API docs are at `/docs`.

For Render, create a separate Blueprint from `render.yaml`, supply `CHATBOT_OPENAI_API_KEY`, and deploy. PostgreSQL is automatically connected to the dedicated `supportpilot-db`; do not attach an existing database. For production, add a custom domain, HTTPS, backups, monitoring, transactional email, billing, legal pages, and provider usage limits.

## Product scope

The included app is suitable as a sellable starter SaaS or internal support tool. Each tenant sees only its own knowledge and conversations. AI answers fail clearly when no provider key is configured. Generated answers must still be monitored for accuracy.
