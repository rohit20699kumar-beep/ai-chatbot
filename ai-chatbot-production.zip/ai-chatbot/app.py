import os, re
from datetime import datetime,timezone
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import Column,Integer,String,Text,DateTime,ForeignKey
from core import Base,engine,SessionLocal,User,password_hash,password_ok,token,current_user,rate_limit,llm,harden

class Conversation(Base):
    __tablename__="conversations"; id=Column(Integer,primary_key=True); user_id=Column(Integer,index=True); title=Column(String(160)); created_at=Column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Message(Base):
    __tablename__="messages"; id=Column(Integer,primary_key=True); conversation_id=Column(Integer,index=True); role=Column(String(20)); content=Column(Text); created_at=Column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Knowledge(Base):
    __tablename__="knowledge"; id=Column(Integer,primary_key=True); user_id=Column(Integer,index=True); title=Column(String(200)); content=Column(Text); created_at=Column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Lead(Base):
    __tablename__="leads"; id=Column(Integer,primary_key=True); user_id=Column(Integer,index=True); email=Column(String(320)); note=Column(Text); created_at=Column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
Base.metadata.create_all(engine)
app=FastAPI(title="SupportPilot AI",version="1.1.0"); harden(app); app.mount("/static",StaticFiles(directory="static"),name="static")

class Auth(BaseModel): email:EmailStr; password:str=Field(min_length=8,max_length=128)
class Chat(BaseModel): conversation_id:int|None=None; message:str=Field(min_length=1,max_length=8000)
class KB(BaseModel): title:str=Field(min_length=2,max_length=200); content:str=Field(min_length=10,max_length=100000)

@app.get("/")
def home():return FileResponse("static/index.html")
@app.get("/health")
def health():return {"status":"ok","service":"SupportPilot AI"}
@app.post("/api/register")
def register(a:Auth,request:Request):
    rate_limit(request,5,300,"register")
    db=SessionLocal()
    if db.query(User).filter(User.email==a.email.lower()).first():db.close();raise HTTPException(409,"Email already registered")
    u=User(email=a.email.lower(),password_hash=password_hash(a.password));db.add(u);db.commit();db.refresh(u);out=token(u);db.close();return {"token":out}
@app.post("/api/login")
def login(a:Auth,request:Request):
    rate_limit(request,10,300,"login",a.email.lower())
    db=SessionLocal();u=db.query(User).filter(User.email==a.email.lower()).first()
    if not u or not password_ok(a.password,u.password_hash):db.close();raise HTTPException(401,"Invalid credentials")
    out=token(u);db.close();return {"token":out}
@app.get("/api/dashboard")
def dashboard(u=Depends(current_user)):
    db=SessionLocal();out={"conversations":db.query(Conversation).filter_by(user_id=u.id).count(),"knowledge":db.query(Knowledge).filter_by(user_id=u.id).count(),"leads":db.query(Lead).filter_by(user_id=u.id).count()};db.close();return out
@app.get("/api/conversations")
def conversations(u=Depends(current_user)):
    db=SessionLocal();rows=db.query(Conversation).filter_by(user_id=u.id).order_by(Conversation.id.desc()).all();out=[{"id":x.id,"title":x.title,"created_at":x.created_at} for x in rows];db.close();return out
@app.get("/api/conversations/{cid}")
def conversation(cid:int,u=Depends(current_user)):
    db=SessionLocal();c=db.query(Conversation).filter_by(id=cid,user_id=u.id).first()
    if not c:db.close();raise HTTPException(404,"Conversation not found")
    rows=db.query(Message).filter_by(conversation_id=cid).order_by(Message.id).all();out=[{"role":x.role,"content":x.content,"created_at":x.created_at} for x in rows];db.close();return out
@app.delete("/api/conversations/{cid}")
def delete_conversation(cid:int,u=Depends(current_user)):
    db=SessionLocal();c=db.query(Conversation).filter_by(id=cid,user_id=u.id).first()
    if not c:db.close();raise HTTPException(404,"Conversation not found")
    db.query(Message).filter_by(conversation_id=cid).delete();db.delete(c);db.commit();db.close();return {"deleted":True}
@app.post("/api/chat")
async def chat(body:Chat,request:Request,u=Depends(current_user)):
    rate_limit(request,30,60,"chat",u.id);db=SessionLocal();c=db.query(Conversation).filter_by(id=body.conversation_id,user_id=u.id).first() if body.conversation_id else None
    if body.conversation_id and not c:db.close();raise HTTPException(404,"Conversation not found")
    if not c:c=Conversation(user_id=u.id,title=body.message[:80]);db.add(c);db.commit();db.refresh(c)
    db.add(Message(conversation_id=c.id,role="user",content=body.message));db.commit()
    docs=db.query(Knowledge).filter_by(user_id=u.id).all();words=set(re.findall(r"[a-z0-9]+",body.message.lower()));scored=[(len(words&set(re.findall(r"[a-z0-9]+",(d.title+" "+d.content).lower()))),d) for d in docs];ranked=[d for score,d in sorted(scored,key=lambda x:x[0],reverse=True) if score>0][:4]
    context="\n\n".join(f"SOURCE: {d.title}\n{d.content[:5000]}" for d in ranked) or "No company knowledge has been uploaded."
    history=db.query(Message).filter_by(conversation_id=c.id).order_by(Message.id.desc()).limit(12).all()[::-1]
    answer=await llm([{"role":m.role,"content":m.content} for m in history],"You are a professional customer-support agent. Use the supplied business knowledge when relevant. Never invent policies. If knowledge is insufficient, say so and offer human escalation. BUSINESS KNOWLEDGE:\n"+context)
    db.add(Message(conversation_id=c.id,role="assistant",content=answer));db.commit();db.close();return {"conversation_id":c.id,"answer":answer,"sources":[d.title for d in ranked]}
@app.get("/api/knowledge")
def list_kb(u=Depends(current_user)):
    db=SessionLocal();rows=db.query(Knowledge).filter_by(user_id=u.id).all();out=[{"id":x.id,"title":x.title,"content":x.content} for x in rows];db.close();return out
@app.post("/api/knowledge")
def add_kb(body:KB,u=Depends(current_user)):
    db=SessionLocal();x=Knowledge(user_id=u.id,title=body.title,content=body.content);db.add(x);db.commit();db.refresh(x);db.close();return {"id":x.id}
@app.delete("/api/knowledge/{kid}")
def delete_kb(kid:int,u=Depends(current_user)):
    db=SessionLocal();x=db.query(Knowledge).filter_by(id=kid,user_id=u.id).first()
    if not x:db.close();raise HTTPException(404,"Not found")
    db.delete(x);db.commit();db.close();return {"deleted":True}
