# Second-pass production audit

Audit status: passed for deployable pilot use after corrections.

## Corrections applied

- Production now refuses startup when `APP_SECRET` is missing or shorter than 32 characters.
- Render PostgreSQL URLs explicitly select the installed Psycopg 3 driver.
- Login and registration have dedicated brute-force rate limits; AI operations have per-account limits.
- Security headers and a restrictive Content Security Policy are applied globally.
- AI-provider error bodies are no longer exposed to customers.
- Provider responses are structurally validated before use.
- Additional authentication, privacy, tenant-isolation and deployment regression tests were added.
- Production data retention defaults were reduced where the product handles sensitive content.

## Launch boundary

The application is complete for a controlled pilot after real provider keys and PostgreSQL are configured. A public paid SaaS launch still requires operator-controlled services: verified email/password recovery, billing, tax invoices, monitoring, backups, customer support, legal policies, vulnerability management and acceptance testing on the final hosting account. Those cannot be truthfully preconfigured inside a distributable ZIP without the owner's accounts and policies.
